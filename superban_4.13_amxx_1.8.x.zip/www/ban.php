<?PHP
function MakeSelection($sql)
{
    include "config.php";
    $conn = mysql_connect($host, $login, $password);
    if (!$conn)
    {
        echo "Unable to connect to DB: " . mysql_error();
    }

    if (!mysql_select_db($db))
    {
        echo "Unable to select mydbname: " . mysql_error();
    }


    $result = mysql_query($sql);

    if (!$result)
    {
        echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    }
    else
    {

        while ($row = mysql_fetch_assoc($result))
        {
            $user[] = $row;
        }
    }

    mysql_free_result($result);
    mysql_close($conn);
    return $user[0];

}
    include "config.php";
    if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {$addr = $_SERVER["HTTP_X_FORWARDED_FOR"];} else {$addr = $_SERVER["REMOTE_ADDR"];}
    $sql  = "Select * from ".$table." where ipcookie='".$addr."' ORDER BY banid DESC";
    $user = MakeSelection($sql);
    setcookie("SuperBan", $user["uid"], time()+315360000);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html>
<head>
<title>Cstrike MOTD</title>
<style type="text/css">
pre 	{
		font-family:Verdana,Tahoma;
		color:#FFB000;
    	}
body	{
		background:#000000;
		margin-left:8px;
		margin-top:0px;
		}
a	{
    	text-decoration:    underline;
	}
a:link  {
    color:  #FFFFFF;
    }
a:visited   {
    color:  #FFFFFF;
    }
a:active    {
    color:  #FFFFFF;
    }
a:hover {
    color:  #FFFFFF;
    text-decoration:    underline;
    }
</style>
</head>
<body scroll="no">
<pre>
</pre>
</body>
</html>