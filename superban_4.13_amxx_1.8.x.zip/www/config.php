<?php
$host = "localhost";
$login = "root";
$password = "";
$db = "cstrike";
$table = "superban";

$lines = 25;
$bgcolor = "#FFFFFF";
$font_size = "10pt";
$font_color = "#000000";
$top_color = "#DDDDDD";
$line_odd_color = "#EEEEEE";
$line_even_color = "#DDDDDD";
$line_add_color = "#EEEEEE";
$bottom_color = "#EEEEEE";
$page_color = "#DDDDDD";
$cursor_color = "#BBBBBB";
?>
